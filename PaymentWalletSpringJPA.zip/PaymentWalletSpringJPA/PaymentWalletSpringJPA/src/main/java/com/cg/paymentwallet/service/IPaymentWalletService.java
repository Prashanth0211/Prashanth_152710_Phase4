package com.cg.paymentwallet.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.paymentwallet.beans.Customer;
import com.cg.paymentwallet.exception.WalletException;

public interface IPaymentWalletService {
	public void createAccount(Customer customer);

	public BigDecimal showBalance(String number);

	public void deposit(String number, BigDecimal amount);

	public String withdraw(String number, BigDecimal amount) throws WalletException;

	public String fundTransfer(String number1, String number2, BigDecimal amount) throws WalletException;

	public String printTransaction(String number);

	public List<Customer> getAllCustomers();

}

