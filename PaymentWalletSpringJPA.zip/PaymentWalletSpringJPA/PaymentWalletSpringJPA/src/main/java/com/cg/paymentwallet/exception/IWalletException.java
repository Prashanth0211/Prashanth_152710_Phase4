package com.cg.paymentwallet.exception;

public interface IWalletException {

	String ERROR1="Insufficeint Balance ";
}
